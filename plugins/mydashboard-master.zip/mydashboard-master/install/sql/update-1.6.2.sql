ALTER TABLE `glpi_plugin_mydashboard_configs` ADD `impact_1` VARCHAR(200) DEFAULT '#228b22' NOT NULL;
ALTER TABLE `glpi_plugin_mydashboard_configs` ADD `impact_2` VARCHAR(200) DEFAULT '#fff03a' NOT NULL;
ALTER TABLE `glpi_plugin_mydashboard_configs` ADD `impact_3` VARCHAR(200) DEFAULT '#ffa500' NOT NULL;
ALTER TABLE `glpi_plugin_mydashboard_configs` ADD `impact_4` VARCHAR(200) DEFAULT '#cd5c5c' NOT NULL;
ALTER TABLE `glpi_plugin_mydashboard_configs` ADD `impact_5` VARCHAR(200) DEFAULT '#8b0000' NOT NULL;