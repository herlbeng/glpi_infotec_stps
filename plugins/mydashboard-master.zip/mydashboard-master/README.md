# mydashboard
Plugin mydashboard for GLPI

![Plugin mydashboard](https://raw.githubusercontent.com/InfotelGLPI/mydashboard/master/screenshots/mydashboard.png "Plugin mydashboard")

Ce plugin est sur Transifex - Aidez-nous à le traduire : https://www.transifex.com/infotelGLPI/GLPI_mydashboard/

This plugin is on Transifex - Help us to translate : https://www.transifex.com/infotelGLPI/GLPI_mydashboard/

WIKI : https://github.com/InfotelGLPI/mydashboard/wiki

Vous pouvez proposer de nouveaux widgets :
http://blogglpi.infotel.com/liste-des-widgets-proposes/

L'article du blog Infotel :
http://blogglpi.infotel.com/une-nouvelle-version-du-plugin-mydashboard-est-en-cours-de-finalisation/
http://blogglpi.infotel.com/une-creation-infotel-le-plugin-my-dashboard/
