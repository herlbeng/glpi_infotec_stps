Dear GLPi user.

For bug reports, you can open an issue here, provide us : 
- The version of the plugin.
- The version of your GLPI.
- The steps to reproduce your issue.

Delete this text to submit your issue.

The Plugin team.
