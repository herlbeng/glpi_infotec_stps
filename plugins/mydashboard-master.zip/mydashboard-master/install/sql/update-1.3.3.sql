ALTER TABLE `glpi_plugin_mydashboard_alerts`
  ADD `type` TINYINT(1) NOT NULL
  AFTER `impact`;