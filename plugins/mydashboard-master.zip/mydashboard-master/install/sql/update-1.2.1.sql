ALTER TABLE `glpi_plugin_mydashboard_alerts`
  ADD `is_public` TINYINT(1) NOT NULL
  AFTER `impact`;